![Logo](http://mattnappo.com/crypt.png)
<br>
[![Build Status](https://travis-ci.com/mitsukomegumi/CryptPy.svg?branch=master)](https://travis-ci.com/mitsukomegumi/CryptPy)


<hr>

Dynamically programmable Python botnet (educational purposes only).

![Logo](http://mattnappo.com/crypt.png)

[![Build Status](https://travis-ci.com/mitsukomegumi/CryptPy.js.svg?branch=master)](https://travis-ci.com/mitsukomegumi/CryptPy.js)
___

Dynamically programmable Python botnet (educational purposes only).

## Installation

### Core Installation with PIP (botnet sources)

```BASH
pip install cryptpy
```

### Building the Node Source (GUI Implementation)

Note: requires installation of cryptpy

First, `cd payload/vbucks`.

Build for MacOS:

1. `npm i`

2. `yarn dist`

Build for Windows:

1. `npm i`

2. `npm run dist`

## Usage

Start a Server:

```bash
cryptpy --server --terminal
```

Start and Register a Bot:

```bash
cryptpy
```

from src.networking import server # Import server

server = server.Server("") # Init server